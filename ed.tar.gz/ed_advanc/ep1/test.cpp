#include "deque.hpp"

int main () {

    Deque<int>* d0 = new Deque<int>();
    Deque<int>* d1 = push_back(d0, 3);
    Deque<int>* d2 = push_back(d1, 4);
    Deque<int>* d3 = push_front(d2, 2);
    Deque<int>* d4 = push_front(d3, 1);

    // cout << "Root:" << front(d1) << " - " << back(d1) << endl;

    cout << "D2:" << front(d2) << " - " << back(d2) << endl;

    cout << "D3:" << front(d3) << " - " << back(d3) << endl;

    cout << "D4:" << front(d4) << " - " << back(d4) << endl;

}