#include <bits/stdc++.h>
#include "node.hpp"

using namespace std;

#define EMPTY -17

/*
Interface:

Deque () : cria e devolve uma degree vozia
Front (d) : devolve o primeiro elemento de d
BACK (d) : i devolve o ieetimo elemento de d
PUSH FRONT (d,x) : insere no initio de deque d e devolve deque resultante
PUSH BACK (d,x) : insere no firm de deque d e devolve adegree resultant)
POP FRONT (d) i remove o primeiro da deque de devolve a deque resuetonk
POP BACK (d) : remove o i-ésimo da deque de devolve a deque resultante
KTH (d,k) : devolve o kchinoelemento da degree d

*/



template<class Value>
class Deque {

    private:
        
        Node<Value>* root;
        Node<Value>* first;
        Node<Value>* last;

    public:
        Deque();

        void set_first (Node<Value>* f);
        Node<Value>* get_first ();

        void set_last (Node<Value>* l);
        Node<Value>* get_last ();

        bool is_empty ();

        ~Deque();
};

/************************************/

// INTERFACE

int front (Deque<int> d);

int back (Deque<int> d);

Deque<int>* push_front (Deque<int>* d, int x);

Deque<int>* push_back (Deque<int>* d, int x); 

// Deque<int>* pop_front (Deque<int>* d); 

// Deque<int>* pop_back (Deque<int>* d); 

int kth (Deque<int>* d, int k); 

/***********************************/



template<class Value>
Deque<Value>::Deque() {

    this->root = this->first = this->last = nullptr;
}

template<class Value>
void Deque<Value>::set_first (Node<Value>* f){

    this->first = f;
   
}

template<class Value>
Node<Value>* Deque<Value>::get_first (){

    return this->first;

}

template<class Value>
void Deque<Value>::set_last (Node<Value>* l){

    this->last = l;

}

template<class Value>
Node<Value>* Deque<Value>::get_last (){

    return this->last;

}

template<class Value>
bool Deque<Value>::is_empty () {

    return this->first == nullptr || this->last == nullptr;

}

/*******************************************/

// IMPLEMENTAÇÃO

int front (Deque<int>* d) {
    
    if (d->get_first() == nullptr) {
        cout << "Empty deque\n";
        return EMPTY;
    }
    return d->get_first()->get_value();

}

int back (Deque<int>* d) {

    if (d->get_last() == nullptr) {
        cout << "Empty deque\n";
        return EMPTY;
    }
    return d->get_last()->get_value();

}

Deque<int>* push_front (Deque<int>* d, int x) {

    Node<int>* node = new Node<int> (x, d->get_first());
    Deque<int>* deque =  new Deque<int>();

    deque->set_first(node);
    
    (d->is_empty()) ? deque->set_last(node) : deque->set_last(d->get_last());

    return deque;
}

Deque<int>* push_back (Deque<int>* d, int x) {

    Node<int>* node = new Node<int> (x, d->get_last());
    Deque<int>* deque =  new Deque<int>();

    deque->set_last(node);
    
    (d->is_empty()) ? deque->set_first(node) : deque->set_first(d->get_first());

    return deque;

}