#include <bits/stdc++.h>
using namespace std;

template<class Value>
class Node {

    private:
    
        Node<Value>* parent;
        Value value;
        int depth;
    
    public:

        Node (Value v, Node<Value>* p);

        Node<Value>* get_parent();
        Value get_value ();
        int get_depth();

        ~Node();
};

/********************************/

// IMPLEMENTATION

template<class Value>
Node<Value>::Node(Value v, Node<Value>* p) {

    this->parent = p;
    this->value = v;
    this->depth = (p == nullptr) ? 1 : p->depth + 1;

}

template<class Value>
Node<Value>* Node<Value>::get_parent() {
    return this->parent;
}

template<class Value>
Value Node<Value>::get_value() {
    return this->value;
}

template<class Value>
int Node<Value>::get_depth() {
    return this->depth;
}

template<class Value>
Node<Value>::~Node() {
    
    parent=nullptr;
}